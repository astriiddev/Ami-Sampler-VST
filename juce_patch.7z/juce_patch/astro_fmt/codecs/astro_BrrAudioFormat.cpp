/*
  ==============================================================================

    BrrAudioFormat.cpp
    Created: 11 Feb 2023 10:44:13am
    Author:  _astriid_

  ==============================================================================
*/

namespace juce
{
    static const char* const brrFormatName = "BRR file";

    namespace BrrFileHelpers
    {
        
        typedef struct BrrFilter
        {
            int16 a, b, tmp[2];
        } brrfilter_t;

        constexpr inline size_t roundUpSize(size_t sz) noexcept { return (sz + 3) & ~3u; }

        /* S-DSP chip uses 16.16 fixed math for its filter coefficients during decoding */
        inline static int16 fixedMath16_16(const int32 in, const int64 numerator, const int32 denominator)
        {
            /* equivalent to (int16) round(numerator / denominator *  in) */
            return (int16) ((in * (numerator << 16) / denominator) >> 16);
        }

        /* converts number of bytes to number of samples as per BRR's 16 sample to 9 byte ratio*/
        inline static int32 bytePos2sampPos(const int64 in)
        {
            /* equivalent to (int32) round(16.0 / 9.0 * (double) in) */
            return (int32) ((in * ((16 << 16) / 9) + 0x8000) >> 16);
        }

        static void clearBrrFilter(brrfilter_t* f)
        {
            f->a = f->b = f->tmp[0] = f->tmp[1] = 0;
        }

        static void setBrrCoeff(brrfilter_t* f, char type)
        {
            switch (type)
            {
                case 1:
                    f->a = fixedMath16_16(f->tmp[0], 15, 16);
                    f->b = 0;
                    break; 
                             
                case 2:      
                    f->a = fixedMath16_16(f->tmp[0], 61, 32);
                    f->b = fixedMath16_16(f->tmp[1], 15, 16);
                    break;
                          
                case 3:
                    f->a = fixedMath16_16(f->tmp[0], 115, 64);
                    f->b = fixedMath16_16(f->tmp[1],  13, 16);
                    break;

                default:
                    f->a = f->b = 0;
                    break;
            }
        }

        static void filterBrr(brrfilter_t* f, const int16 shifted_samp, int16 *sample)
        {
            const int16 out = shifted_samp + f->a - f->b;

            f->tmp[1] = f->tmp[0];
            f->tmp[0] = out;
            *sample = out;
        }

        struct SampleLoopHeader
        {
            int32 loopStart;
            int32 loopEnd;

            template <typename NameType>
            static void setValue(StringMap& values, NameType name, int32 val)
            {
                values[name] = String(ByteOrder::swapIfBigEndian(val));
            }

            static void setValue(StringMap& values, int prefix, const char* name, int32 val)
            {
                setValue(values, "Loop" + String(prefix) + name, val);
            }

            void copyTo(StringMap& values, const int /* totalSize */) const
            {
                setValue(values, 0, "Start",  loopStart);
                setValue(values, 0, "End", loopEnd - 1);
            }

            template <typename NameType>
            static int32 getValue(const StringMap& values, NameType name, const char* def)
            {
                return (int32) getValueWithDefault(values, name, def).getIntValue();
            }

            static int32 getValue(const StringMap& values, int prefix, const char* name, const char* def)
            {
                return getValue(values, "Loop" + String(prefix) + name, def);
            }

            static MemoryBlock createFrom(const StringMap& values)
            {
                MemoryBlock data;
                data.setSize(roundUpSize(sizeof(SampleLoopHeader)), true);

                auto s = static_cast<SampleLoopHeader*> (data.getData());

                s->loopStart = getValue(values, 0, "Start", "0");
                s->loopEnd = getValue(values, 0, "End", "0");

                return data;
            }
        } JUCE_PACKED;
    }

    class BrrAudioFormatReader : public AudioFormatReader
    {
    public:
        BrrAudioFormatReader(InputStream* in) : AudioFormatReader(in, brrFormatName)
        {
            fileLength = in->getTotalLength();
            numChannels = 1;
            sampleRate = 16744;
            bitsPerSample = 16;
            bytesPerFrame = 2;
            dataLength = getBrrLength(fileLength, input);

            lengthInSamples = (bytesPerFrame > 0) ? (dataLength * 2 / bytesPerFrame) : 0;

            usesFloatingPointData = false;
        }

        int64 getBrrLength(const int64 length, InputStream* input)
        {
            using namespace BrrFileHelpers;

            if (length % 9 == 0)
            {
                dataStart = 0;

                hasLoop = false;
                loopStart = bytePos2sampPos(length);
                loopEnd = loopStart;

                return (int64) loopStart;
            }
            else if ((length - 2) % 9 == 0)
            {
                input->setPosition(0);

                dataStart = 2;
                hasLoop = true;
                loopStart = bytePos2sampPos(input->readShort());

                return (int64) bytePos2sampPos(length - 2);
            }
            else
            {
                loopStart = 0;
                loopEnd   = 0;
                dataStart = 0;

                return 0;
            }
        }

        void decodeBrr(int16* destBuffer, const char* sourceBuffer, int* start, int bytesToDecode)
        {
            using namespace BrrFileHelpers;

            bool  loopFlag   = false, 
                  endFlag    = false;

            int   endFlagPos = 0, i = *start;

            int8  filterFlag = 0,
                  shifter    = 0;

            int16 temp_samp  = 0;

            while (--bytesToDecode >= 0)
            {
                uint8 inSample = (uint8) *sourceBuffer++;

                if ((i - dataStart) % 9 == 0)
                {
                    shifter = (inSample & ~0x0F) >> 4;
                    if (shifter > 12) shifter = 12;

                    filterFlag = (inSample & ~0xF3) >> 2;
                    if (filterFlag > 3) filterFlag = 3;

                    loopFlag = (inSample & 0x02) ? true : false;

                    if (inSample & 0x01)
                    {
                        endFlag = true;
                        endFlagPos = i;

                        if (loopFlag && endFlag)
                        {
                            hasLoop = true;
                            loopEnd = bytePos2sampPos(i + 7);
                        }
                        else
                        {
                            hasLoop = false;
                            loopStart = (int32) dataLength;
                            loopEnd = loopStart;
                        }
                    }
                    else
                    {
                        endFlag = false;
                        endFlagPos = (int) fileLength;
                    }
                }

                else if ((i - dataStart) % 9 != 0 && shifter <= 12)
                {
                    if ((i - dataStart) > 0)
                    {
                        char nibble = 0;

                        nibble = ((inSample & ~0x0F) >> 4);
                        if (nibble > 7) nibble ^= 0xF0;

                        setBrrCoeff(&brrfilter, filterFlag);
                        filterBrr(&brrfilter, nibble << shifter, &temp_samp);

                        *destBuffer++ = temp_samp;

                        nibble = (inSample & ~0xF0);
                        if (nibble > 7) nibble ^= 0xF0;

                        setBrrCoeff(&brrfilter, filterFlag);
                        filterBrr(&brrfilter, nibble << shifter, &temp_samp);

                        *destBuffer++ = temp_samp;
                    }
                }

                i++;
            }

            *start = i;
        }

        bool readSamples(int* const* destSamples, int numDestChannels, int startOffsetInDestBuffer,
            int64 startSampleInFile, int numSamples) override
        {
            int blockPos = (int) dataStart;
            using namespace BrrFileHelpers;

            StringMap dict;

            HeapBlock<SampleLoopHeader> loop;
            loop.calloc(jmax((size_t)8, sizeof(SampleLoopHeader)), 1);

            clearSamplesBeyondAvailableLength(destSamples, numDestChannels, startOffsetInDestBuffer,
                startSampleInFile, numSamples, lengthInSamples);

            if (numSamples <= 0)
                return true;

            input->setPosition(blockPos);
            clearBrrFilter(&brrfilter);

            while (numSamples > 0)
            {
                const int tempBufSize = 480 * 3 * 4;
                const int tempBrrBuffSize = bytePos2sampPos(tempBufSize);

                char tempBuffer[tempBufSize];
                int16 *tempBrrBuffer = new int16[tempBrrBuffSize];

                auto numBlockThisTime = jmin(tempBufSize, (int) fileLength);
                auto bytesRead = input->read(tempBuffer, numBlockThisTime);

                auto numSampThisTime  = jmin(tempBrrBuffSize, numSamples);

                zeromem(tempBrrBuffer, tempBrrBuffSize);

                if (bytesRead < numBlockThisTime)
                {
                    jassert(bytesRead >= 0);
                    zeromem(tempBuffer + bytesRead, (size_t)(tempBufSize - bytesRead));
                }

                decodeBrr(tempBrrBuffer, tempBuffer, &blockPos, numBlockThisTime);

                copySampleData(bitsPerSample, usesFloatingPointData,
                    destSamples, startOffsetInDestBuffer, numDestChannels,
                    tempBrrBuffer, (int)numChannels, numSampThisTime);

                startOffsetInDestBuffer += numSampThisTime;
                numSamples -= numSampThisTime;

                delete[] tempBrrBuffer;
                tempBrrBuffer = nullptr;
            }

            loop.get()->loopStart = loopStart;
            loop.get()->loopEnd = loopEnd;

            loop->copyTo(dict, 8);

            if (dict.size() > 0)            dict["MetaDataSource"] = "BRR";

            metadataValues.addUnorderedMap(dict);

            return true;
        }

        static void copySampleData(unsigned int /*numBitsPerSample*/, const bool /*floatingPointData*/,
            int* const* destSamples, int startOffsetInDestBuffer, int numDestChannels,
            const void* sourceData, int numberOfChannels, int numSamples) noexcept
        {
            ReadHelper<AudioData::Int32, AudioData::Int16, AudioData::LittleEndian>::read(destSamples, startOffsetInDestBuffer, numDestChannels, sourceData, numberOfChannels, numSamples);
        }

        int64 dataStart = 0, dataLength = 0;
        int bytesPerFrame = 0;

    private:
        
        BrrFileHelpers::brrfilter_t brrfilter;

        int64  fileLength = 0;
        int32 loopStart = 0, loopEnd = 0;
        bool hasLoop = false;

        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(BrrAudioFormatReader)
    };

    //==============================================================================

/*
 *
 * TODO!!!! Port BRR encoder into JUCE format writer!
 *
 */


class BrrAudioFormatWriter : public AudioFormatWriter
    {
    public:
        BrrAudioFormatWriter(OutputStream* const out, const double rate,
                            const AudioChannelSet& channelLayoutToUse, const unsigned int bits)
            : AudioFormatWriter(out, brrFormatName, rate, channelLayoutToUse, bits)
        {
            usesFloatingPointData = false;
        }

        ~BrrAudioFormatWriter() override
        {
        }


        bool write(const int** /* data */, const int /* numSamples */) override
        {
            
            /*
            *
            * TODO!!!! Port BRR encoder into JUCE format writer!
            *
            */

            return false;
            /*int* decodedBuffer = new int[numSamples];
            //int decodedBuffer[numSamples];

            jassert(numSamples >= 0);
            jassert(data != nullptr && *data != nullptr); // the input must contain at least one channel!
            
            if (writeFailed)
                return false;

            auto bytes = numChannels * (size_t)numSamples * bitsPerSample / 8;
            tempBlock.ensureSize(bytes, false);

            WriteHelper<AudioData::UInt8, AudioData::Int32, AudioData::LittleEndian>::write(tempBlock.getData(), (int)numChannels, &decodedBuffer, numSamples);

            if (!output->write(tempBlock.getData(), bytes))
            {
                // failed to write to disk, so let's try writing the header.
                // If it's just run out of disk space, then if it does manage
                // to write the header, we'll still have a usable file..
                delete[] decodedBuffer;
                decodedBuffer = nullptr; 
                writeFailed = true;
                return false;
            }

            delete[] decodedBuffer;
            decodedBuffer = nullptr; 
            bytesWritten += bytes;
            lengthInSamples += (uint64)numSamples;
            return true;*/
        }

        bool flush() override
        {
            auto lastWritePos = output->getPosition();

            if (output->setPosition(lastWritePos))
                return true;

            // if this fails, you've given it an output stream that can't seek! It needs
            // to be able to seek back to write the header
            jassertfalse;
            return false;
        }

    private:
        MemoryBlock tempBlock;
        uint64 lengthInSamples = 0, bytesWritten = 0;
        bool writeFailed = false;

        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(BrrAudioFormatWriter)
    };

    //==============================================================================
    
    BrrAudioFormat::BrrAudioFormat() : AudioFormat(brrFormatName, ".brr") {}
    BrrAudioFormat::~BrrAudioFormat() {}

    Array<int> BrrAudioFormat::getPossibleSampleRates() { return 8363; }
    Array<int> BrrAudioFormat::getPossibleBitDepths() { return 8; }

    bool BrrAudioFormat::canDoStereo() { return false; }
    bool BrrAudioFormat::canDoMono() { return true; }

    bool BrrAudioFormat::isChannelLayoutSupported(const AudioChannelSet& channelSet) 
    { 
        return channelSet == AudioChannelSet::mono() ? true : false; 
    }

    AudioFormatReader* BrrAudioFormat::createReaderFor(InputStream* sourceStream, bool deleteStreamIfOpeningFails)
    {
        std::unique_ptr<BrrAudioFormatReader> r(new BrrAudioFormatReader(sourceStream));

        if (r->lengthInSamples > 0)
            return r.release();

        if (!deleteStreamIfOpeningFails)
            r->input = nullptr;

        return nullptr;
    }

    //==============================================================================

    AudioFormatWriter* BrrAudioFormat::createWriterFor(OutputStream* /* out */)
    {
        return nullptr;
    }

    AudioFormatWriter* BrrAudioFormat::createWriterFor(OutputStream* /* out */, double /* sampleRateToUse */,
                                                    unsigned int /* numberOfChannels */, int /* bitsPerSample */,
                                                    const StringPairArray& /* metadataValues */, int /* qualityOptionIndex */)
    {
        return nullptr;
    }
};