param([string]$juce_dir)

function endscript {
write-host $files_copied files copied!
exit
}

function checkDir
{
    param(
        [string]$targetDir
    )

    if (-not(Test-Path -Path $targetDir)) 
    {
        write-host Cannot find $targetDir
        endscript
    }

}

function copyFile
{
    param(
        [string]$fileToCopy,
        [string]$targetDir
    )

    if (-not(Test-Path -Path $targetDir)) 
    {
        write-host Cannot find $targetDir
        endscript
    }

    if (-not(Test-Path $fileToCopy)) 
    {
        write-host Cannot find $fileToCopy
        endscript
    }

    write-host Copied $targetDir to $fileToCopy
    Copy-Item $fileToCopy $targetDir

}

if ($juce_dir -eq "")
{
	write-host JUCE format directory not set!
	endscript
}

$working_dir = Split-Path -Parent $PSCommandPath
$files_copied = 0

$target_dir = $juce_dir + "/modules/juce_gui_basics/native/"
checkDir -targetDir $target_dir

copyFile -fileToCopy $working_dir/"juce_Windowing_windows.cpp" -targetDir $target_dir

$files_copied++

$target_dir = $juce_dir + "/modules/juce_audio_formats/"
checkDir -targetDir $target_dir

copyFile -fileToCopy $working_dir/"astro_fmt/juce_audio_formats.cpp" -targetDir $target_dir
copyFile -fileToCopy $working_dir/"astro_fmt/juce_audio_formats.h" -targetDir $target_dir

$files_copied+=2

$target_dir = $juce_dir + "/modules/juce_audio_formats/format/"
checkDir -targetDir $target_dir

copyFile -fileToCopy $working_dir/"astro_fmt/format/juce_AudioFormatManager.cpp" -targetDir $target_dir
copyFile -fileToCopy $working_dir/"astro_fmt/format/juce_AudioFormatManager.h" -targetDir $target_dir

$files_copied+=2

$target_dir = $juce_dir + "/modules/juce_audio_formats/codecs/"
checkDir -targetDir $target_dir

copyFile -fileToCopy $working_dir/"astro_fmt/codecs/astro_BrrAudioFormat.cpp" -targetDir $target_dir
copyFile -fileToCopy $working_dir/"astro_fmt/codecs/astro_BrrAudioFormat.h" -targetDir $target_dir

copyFile -fileToCopy $working_dir/"astro_fmt/codecs/astro_IffAudioFormat.cpp" -targetDir $target_dir
copyFile -fileToCopy $working_dir/"astro_fmt/codecs/astro_IffAudioFormat.h" -targetDir $target_dir

copyFile -fileToCopy $working_dir/"astro_fmt/codecs/astro_MuLawFormat.cpp" -targetDir $target_dir
copyFile -fileToCopy $working_dir/"astro_fmt/codecs/astro_MuLawFormat.h" -targetDir $target_dir

$files_copied+=6

write-host `nCopied $files_copied files to $juce_dir `n
