juce_dir=$1

files_copied=0

function endscript() {
    echo "$files_copied files copied!"
    exit 1
}

function check_dir() {
    if [ ! -d $1 ]
    then
        echo "Cannot find $1!"
        endscript
    fi
}

function copy_file() {
    if [ ! -f $1 ]
    then
        echo "Cannot find $1!"
        endscript
    fi

    if [ ! -d $2 ]
    then
        echo "Cannot find $1!"
        endscript
    fi

    cp $1 $2
    echo "Copied $1 to $2"
    files_copied=$((files_copied+1))
}

if [[ -z "$juce_dir" ]]
then
    echo "JUCE directory not set!"
    endscript
fi

working_dir=$(dirname "$0")

target_dir=$juce_dir/modules/juce_gui_basics/native
check_dir $target_dir

copy_file $working_dir/juce_Windowing_windows.cpp $target_dir

target_dir=$juce_dir/modules/juce_audio_formats
check_dir $target_dir

copy_file $working_dir/astro_fmt/juce_audio_formats.cpp $target_dir
copy_file $working_dir/astro_fmt/juce_audio_formats.h $target_dir

target_dir=$juce_dir/modules/juce_audio_formats/format
check_dir $target_dir

copy_file $working_dir/astro_fmt/format/juce_AudioFormatManager.cpp $target_dir
copy_file $working_dir/astro_fmt/format/juce_AudioFormatManager.h $target_dir

target_dir=$juce_dir/modules/juce_audio_formats/codecs
check_dir $target_dir

copy_file $working_dir/astro_fmt/codecs/astro_BrrAudioFormat.cpp $target_dir
copy_file $working_dir/astro_fmt/codecs/astro_BrrAudioFormat.h $target_dir

copy_file $working_dir/astro_fmt/codecs/astro_iffAudioFormat.cpp $target_dir
copy_file $working_dir/astro_fmt/codecs/astro_iffAudioFormat.h $target_dir

copy_file $working_dir/astro_fmt/codecs/astro_MuLawFormat.cpp $target_dir
copy_file $working_dir/astro_fmt/codecs/astro_MuLawFormat.h $target_dir

echo -e "\nCopied $files_copied files to $juce_dir\n"

